import os

from matplotlib import pyplot as plt
from tqdm import tqdm
import numpy as np
# from xgboost import XGBClassifier
import xgboost as xgb
from sklearn.model_selection import train_test_split
from DatasetPreprocessing import read_csvFile
from ImageDigitalFeatures import imageFeatures


# city = pd.DataFrame([['dd','sss'],['ddssa','dfdfds']],columns=['name','namsds'])
# city.to_csv('image_features.csv', index=False)

def makeFeatures(imgPath, labelcsv,mod):
    # mod 等于1时是全数据集
    if isinstance(labelcsv, list):
        length = 0
        for i in labelcsv:
            length += len(os.listdir(imgPath + '/' + str(i)))
        label = []
        features = np.zeros((length, 6))
        NUM = 0
        for iLabel in labelcsv:
            img = os.listdir(imgPath + '/' + str(iLabel))
            for Img in tqdm(img):
                label.append(iLabel)
                contrast, dissimilarity, homogeneity, ASM, energy, correlation = imageFeatures(
                    imgPath + '/' + str(iLabel) + '//' + Img)
                features[NUM, :] = [contrast[0][0], dissimilarity[0][0], homogeneity[0][0], ASM[0][0], energy[0][0],
                                    correlation[0][0]]
                NUM += 1
        return label, features
    if mod == 1:
        datapath = 'F:\AProject\DataSet\ZHZK\MGD_DataSet_all'
        imgstr1 = []
        imgLabel = []
        for dataLabel in ['train', 'test', 'val']:
            templist = os.listdir(datapath + dataLabel)
            for DataLabel in templist:
                path = datapath + dataLabel + '/' + DataLabel + '/'
                imglist = os.listdir(path)
                for img in imglist:
                    imgstr1.append(path + img)
                    imgLabel.append(DataLabel)
        Imgdic = read_csvFile(labelcsv)
        Imglis = imgstr1
        label = []
        features = np.zeros((len(Imglis), 6))
        i = 0
        for img in tqdm(Imglis):
            img_label = eval(Imgdic[img])
            label.append(img_label)
            contrast, dissimilarity, homogeneity, ASM, energy, correlation = imageFeatures(img)
            features[i, :] = [contrast[0][0], dissimilarity[0][0], homogeneity[0][0], ASM[0][0], energy[0][0],
                              correlation[0][0]]
            i += 1
    else:
        Imgdic = read_csvFile(labelcsv)
        Imglis = os.listdir(imgPath)
        label = []
        features = np.zeros((len(Imglis), 6))
        i = 0
        for img in tqdm(Imglis):
            img_label = eval(Imgdic[img])
            label.append(img_label)
            contrast, dissimilarity, homogeneity, ASM, energy, correlation = imageFeatures(imgPath + '//' + img)
            features[i, :] = [contrast[0][0], dissimilarity[0][0], homogeneity[0][0], ASM[0][0], energy[0][0],
                              correlation[0][0]]
            i += 1
    return label, features


def Features_Importance(imgPath, labelcsv, outPath,mod):
    labels, features = makeFeatures(imgPath, labelcsv,mod)
    # 划分训练集和测试集
    X_train, X_test, y_train, y_test = train_test_split(features, labels, test_size=0.2, random_state=42)

    # 构建XGBoost训练集和测试集
    dtrain = xgb.DMatrix(X_train, label=y_train,
                         feature_names=['Contrast', 'Dissimilarity', 'Homogeneity', 'ASM', 'Energy', 'Correlation'])
    dtest = xgb.DMatrix(X_test, label=y_test,
                        feature_names=['Contrast', 'Dissimilarity', 'Homogeneity', 'ASM', 'Energy', 'Correlation'])

    # 定义XGBoost参数
    params = {
        'objective': 'multi:softmax',  # 多分类问题的目标函数
        'num_class': len(np.unique(labels)),  # 标签类别数
        'max_depth': 3,  # 决策树最大深度
        'eta': 0.1,  # 学习率
        'gamma': 0,  # 分裂时损失函数的最小减少量
        'subsample': 0.8,  # 每棵树样本的随机采样比例
        'colsample_bytree': 0.8  # 每棵树特征的随机采样比例
    }

    # 训练XGBoost模型
    num_rounds = 100  # 迭代轮数
    model = xgb.train(params, dtrain, num_rounds)

    # 获取特征重要性评分
    feature_importances = model.get_score(importance_type='gain')

    # 根据特征重要性排序
    sorted_features = sorted(feature_importances, key=lambda x: feature_importances[x], reverse=True)

    # 筛选重要特征
    top_k = 6  # 筛选前k个重要特征
    selected_features = sorted_features[:top_k]

    # 输出筛选结果

    sorted_features = sorted(feature_importances, key=lambda x: feature_importances[x], reverse=True)

    # 输出特征重要性排序结果
    print("Feature Importance:")
    outstream = ''
    for feature in sorted_features:
        # print(f"{feature}: {feature_importances[feature]}")
        print(f"{feature}")
        outstream += f"{feature}: {feature_importances[feature]}+/n"
    for feature in sorted_features:
        # print(f"{feature}: {feature_importances[feature]}")
        print(f"{feature_importances[feature]}")
    with open(outPath + '/output.txt', 'w', encoding='utf-8') as f:
        f.writelines(outstream)
    f.close()

    # 可视化特征重要性
    plt.bar(range(len(sorted_features)), [feature_importances[feature] for feature in sorted_features])
    plt.xticks(range(len(sorted_features)), sorted_features)
    plt.xlabel('Features')
    plt.ylabel('Importance Score')
    plt.title('Feature Importance')
    plt.savefig(outPath + '/out.jpg')
