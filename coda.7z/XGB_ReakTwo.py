from XGB_Features import Features_Importance

Features_Importance(r'F:\AProject\DataSet\ZHZK\MGD_DataSet_all\Data\original\Real-world rataset-2',
                    r"F:\AProject\DataSet\ZHZK\MGD_DataSet_all\Data\original\Real_2.csv",
                    r"F:\ZHZK\ziatPro\XAI\code\XGBoost\temp",mod=0)