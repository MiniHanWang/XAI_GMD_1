import csv
import os

import numpy as np
import pandas
import cv2
from tqdm import tqdm


def dataAugmentation(path, despath, classnum):
    ##
    # 用于图片的翻转 水平，镜像
    # 参考：
    # dataAugmentation(r'..\Dataset\train\0\000001.png', r'F:\AProject', r'.//Dataset\N_MGD', 0)
    ##
    """ 
    :param path: 图片地址
    :param despath: 存储地址
    :param classnum: 分类名称
    :return: null
    """

    ###
    img = cv2.imread(path)
    # Flipped Horizontally 水平翻转
    h_flip = cv2.flip(img, 1)
    h_flip_img = cv2.resize(img, [1360, 1024], interpolation=cv2.INTER_CUBIC)
    strnum = str(len(os.listdir(despath + "/{}/".format(classnum))) + 1).rjust(6, '0')
    cv2.imwrite(despath + "/{}/".format(classnum) + strnum + '.png', h_flip_img)

    # Flipped Vertically 垂直翻转
    v_flip = cv2.flip(img, 0)
    v_flip_img = cv2.resize(img, [1360, 1024], interpolation=cv2.INTER_CUBIC)
    strnum = str(len(os.listdir(despath + "/{}/".format(classnum))) + 1).rjust(6, '0')
    cv2.imwrite(despath + "/{}/".format(classnum) + strnum + '.png', v_flip_img)

    # Flipped Horizontally & Vertically 水平垂直翻转
    hv_flip = cv2.flip(img, -1)
    hv_flip_img = cv2.resize(img, [1360, 1024], interpolation=cv2.INTER_CUBIC)
    strnum = str(len(os.listdir(despath + "/{}/".format(classnum))) + 1).rjust(6, '0')
    cv2.imwrite(despath + "/{}/".format(classnum) + strnum + '.png', hv_flip_img)


def dataAugmentation(path, despath, classnum):
    ##
    # 用于图片的翻转 水平，镜像
    # 参考：
    # dataAugmentation(r'..\Dataset\train\0\000001.png', r'F:\AProject', r'.//Dataset\N_MGD', 0)
    ##
    """
    :param path: 图片地址
    :param despath: 存储地址
    :param classnum: 分类名称
    :return: null
    """

    ###
    img = cv2.imread(path)
    # Flipped Horizontally 水平翻转
    h_flip = cv2.flip(img, 1)
    h_flip_img = cv2.resize(img, [1360, 1024], interpolation=cv2.INTER_CUBIC)
    strnum = str(len(os.listdir(despath + "/{}/".format(classnum))) + 1).rjust(6, '0')
    cv2.imwrite(despath + "/{}/".format(classnum) + strnum + '.png', h_flip_img)

    # Flipped Vertically 垂直翻转
    v_flip = cv2.flip(img, 0)
    v_flip_img = cv2.resize(img, [1360, 1024], interpolation=cv2.INTER_CUBIC)
    strnum = str(len(os.listdir(despath + "/{}/".format(classnum))) + 1).rjust(6, '0')
    cv2.imwrite(despath + "/{}/".format(classnum) + strnum + '.png', v_flip_img)

    # Flipped Horizontally & Vertically 水平垂直翻转
    hv_flip = cv2.flip(img, -1)
    hv_flip_img = cv2.resize(img, [1360, 1024], interpolation=cv2.INTER_CUBIC)
    strnum = str(len(os.listdir(despath + "/{}/".format(classnum))) + 1).rjust(6, '0')
    cv2.imwrite(despath + "/{}/".format(classnum) + strnum + '.png', hv_flip_img)


def img_Contract(imgpath,savepath):
    # 图像灰度归一

    img = cv2.imread(imgpath, 0)
    # flatten() 将数组变成一
    equ = cv2.equalizeHist(img)
    # stacking images side-by-side
    cv2.imwrite(savepath, equ)





def read_csvFile(path):
    """
    读取csv文件，并返回列数据
    :param path:
    :return: 各列数据
    """
    dic1 = {}
    csv_reader = csv.reader(open(path))
    for line in csv_reader:
        dic1[line[0]]=line[1]
    return dic1




if __name__ == '__main__':
    # csvData = read_csvFile(r'F:\AProject\DataSet\ZHZK\MGD1k-main\Expore MGD1k Dataset\Graded Meiboscore\Images with '
    #              r'Meiboscore.csv')
    # Path = r'F:\AProject\DataSet\ZHZK\MGD1k-main\Expore MGD1k Dataset\Original Images'
    # pathlist = os.listdir(Path)
    # for name in tqdm(pathlist):
    #     try:
    #         dataAugmentation(Path+'/'+name, r'F:\AProject\PycharmProject\ZHZK\xerophthalmia\Dataset\train', csvData[name])
    #     except KeyError:
    #         print("Error_" + name+'\n')
    img_Contract(r'D:\Project\xerophthalmia\Dataset\MGD_DataSet_all\train\0\000002.png',r'D:\Project\xerophthalmia\Dataset\MGD_DataSet_all\train\0\a.png')




