import numpy as np
from skimage.feature import graycomatrix, graycoprops
from skimage.io import imread
from skimage import img_as_ubyte
import cv2
from skimage.feature import graycomatrix, graycoprops


def imageFeatures(imgPath):
    # 读取图像
    image = imread(imgPath, as_gray=True)
    image = img_as_ubyte(image)
    # 计算灰度共生矩阵
    distances = [1]  # GLCM距离，可以根据需要进行调整
    angles = [0]  # GLCM角度，可以根据需要进行调整
    glcm = graycomatrix(image, distances, angles, levels=256, symmetric=True, normed=True)

    # 提取纹理特征
    contrast = graycoprops(glcm, 'contrast')
    dissimilarity = graycoprops(glcm, 'dissimilarity')
    homogeneity = graycoprops(glcm, 'homogeneity')
    ASM = graycoprops(glcm, 'ASM')
    energy = graycoprops(glcm, 'energy')
    correlation = graycoprops(glcm, 'correlation')
    return contrast, dissimilarity, homogeneity, ASM, energy, correlation


def normalize_image_texture(image):
    # image: numpy array representing the image

    # Convert the image to grayscale if it's in color
    if len(image.shape) > 2:
        image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    # Calculate the GLCM matrix
    glcm = graycomatrix(image, distances=[1], angles=[0], levels=256, symmetric=True, normed=True)

    # Calculate texture features
    contrast = graycoprops(glcm, 'contrast')[0, 0]
    dissimilarity = graycoprops(glcm, 'dissimilarity')[0, 0]
    homogeneity = graycoprops(glcm, 'homogeneity')[0, 0]
    energy = graycoprops(glcm, 'energy')[0, 0]
    correlation = graycoprops(glcm, 'correlation')[0, 0]
    asm = graycoprops(glcm, 'ASM')[0, 0]

    # Normalize the image based on texture features
    normalized_image = (image - np.min(image)) / (np.max(image) - np.min(image))
    normalized_contrast = (normalized_image * (np.max(contrast) - np.min(contrast))) + np.min(contrast)
    normalized_dissimilarity = (normalized_image * (np.max(dissimilarity) - np.min(dissimilarity))) + np.min(
        dissimilarity)
    normalized_homogeneity = (normalized_image * (np.max(homogeneity) - np.min(homogeneity))) + np.min(homogeneity)
    normalized_energy = (normalized_image * (np.max(energy) - np.min(energy))) + np.min(energy)
    normalized_correlation = (normalized_image * (np.max(correlation) - np.min(correlation))) + np.min(correlation)
    normalized_asm = (normalized_image * (np.max(asm) - np.min(asm))) + np.min(asm)

    return normalized_image, normalized_contrast, normalized_dissimilarity, normalized_homogeneity, normalized_energy, normalized_correlation, normalized_asm


if __name__ == '__main__':
    normalized_image, normalized_contrast, normalized_dissimilarity, normalized_homogeneity, normalized_energy, normalized_correlation, normalized_asm = normalize_image_texture(
        cv2.imread(r'D:\Project\xerophthalmia\Dataset\MGD_DataSet_all\train\0\000002.png'))
    cv2.imwrite(r'D:\Project\xerophthalmia\TempTest/normalized_image.png', normalized_image)
    cv2.imwrite(r'D:\Project\xerophthalmia\TempTest/normalized_contrast.png', normalized_contrast)
    cv2.imwrite(r'D:\Project\xerophthalmia\TempTest/normalized_dissimilarity.png', normalized_dissimilarity)
    cv2.imwrite(r'D:\Project\xerophthalmia\TempTest/normalized_homogeneity.png', normalized_homogeneity)
    cv2.imwrite(r'D:\Project\xerophthalmia\TempTest/normalized_energy.png', normalized_energy)
    cv2.imwrite(r'D:\Project\xerophthalmia\TempTest/normalized_correlation.png', normalized_correlation)
    cv2.imwrite(r'D:\Project\xerophthalmia\TempTest/normalized_asm.png', normalized_asm)
    cv2.imwrite(r'D:\Project\xerophthalmia\TempTest/normalized_or.png', cv2.imread(r'D:\Project\xerophthalmia\Dataset\MGD_DataSet_all\train\0\000002.png'))
